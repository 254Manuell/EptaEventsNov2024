"use client";

import { useState, FormEvent, useCallback } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { storage, firestore } from "@/firebase/config";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { collection, addDoc } from "firebase/firestore";
import { toast } from "react-hot-toast";
import { motion, AnimatePresence } from "framer-motion";
import { FiUpload, FiX, FiCheck } from "react-icons/fi";
import dynamic from 'next/dynamic';
import { Editor } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Placeholder from '@tiptap/extension-placeholder';
import { useEditor } from '@tiptap/react';

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
const ALLOWED_FILE_TYPES = ["image/jpeg", "image/png", "image/gif", "image/webp"];

const Toolbar = dynamic(() => import('./components/Toolbar'), {
  ssr: false,
});

interface EventForm {
  title: string;
  date: string;
  time: string;
  location: string;
  description: string;
  capacity: string;
  category: string;
  price: string;
  ticketTypes: TicketType[];
  isRecurring: boolean;
  recurringFrequency?: string;
  endDate?: string;
}

interface TicketType {
  name: string;
  price: number;
  quantity: number;
}

export default function CreateEventPage() {
  const { user } = useAuth();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [retryCount, setRetryCount] = useState(0);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>("");
  const [imageError, setImageError] = useState<string>("");
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);

  const [formData, setFormData] = useState<EventForm>({
    title: "",
    date: "",
    time: "",
    location: "",
    description: "",
    capacity: "",
    category: "",
    price: "",
    ticketTypes: [],
    isRecurring: false,
    recurringFrequency: undefined,
    endDate: undefined,
  });

  const editor = useEditor({
    extensions: [
      StarterKit,
      Placeholder.configure({
        placeholder: 'Describe your event...',
      }),
    ],
    onUpdate: ({ editor }) => {
      setFormData(prev => ({
        ...prev,
        description: editor.getHTML(),
      }));
    },
  });

  const categories = [
    { id: "weddings", name: "Weddings", icon: "💒" },
    { id: "corporate", name: "Corporate Events", icon: "🏢" },
    { id: "birthdays", name: "Birthdays", icon: "🎂" },
    { id: "graduations", name: "Graduations", icon: "🎓" },
    { id: "cultural", name: "Cultural Events", icon: "🎭" },
    { id: "concerts", name: "Concerts", icon: "🎵" },
    { id: "sports", name: "Sports Events", icon: "⚽" },
    { id: "workshops", name: "Workshops", icon: "🛠️" },
    { id: "other", name: "Other", icon: "📌" },
  ];

  const handleImageValidation = useCallback((file: File): string | null => {
    if (!file) return "Please select an image file";
    if (file.size > MAX_FILE_SIZE) return "Image size must be less than 5MB";
    if (!ALLOWED_FILE_TYPES.includes(file.type)) return "Please upload a valid image file (JPEG, PNG, GIF, or WebP)";
    return null;
  }, []);

  const handleImageChange = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    setImageError("");
    setUploadSuccess(false);
    const file = e.target.files?.[0];

    if (file) {
      const validationError = handleImageValidation(file);
      if (validationError) {
        setImageError(validationError);
        return;
      }

      try {
        setIsUploading(true);
        // Create preview
        const reader = new FileReader();
        reader.onloadend = () => {
          setImagePreview(reader.result as string);
        };
        reader.readAsDataURL(file);
        setImageFile(file);
      } catch (err) {
        setImageError("Failed to process image. Please try again.");
        console.error("Image processing error:", err);
      } finally {
        setIsUploading(false);
      }
    }
  }, [handleImageValidation]);

  const uploadImage = async (file: File): Promise<string> => {
    const maxRetries = 3;
    let attempt = 0;

    while (attempt < maxRetries) {
      try {
        const storageRef = ref(storage, `event-images/${formData.category.toLowerCase()}/${Date.now()}-${file.name}`);
        setUploadProgress(0);

        const uploadTask = uploadBytes(storageRef, file);
        const snapshot = await uploadTask;

        // Get download URL
        const url = await getDownloadURL(snapshot.ref);
        setUploadProgress(100);
        setUploadSuccess(true);
        return url;
      } catch (error) {
        attempt++;
        if (attempt === maxRetries) throw error;
        // Exponential backoff
        await new Promise((resolve) => setTimeout(resolve, Math.pow(2, attempt) * 1000));
      }
    }
    throw new Error("Failed to upload image after multiple attempts");
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast.error("Please sign in to create an event");
      return;
    }

    setLoading(true);
    setError("");
    setUploadProgress(0);

    try {
      let imageUrl = "";
      if (imageFile) {
        imageUrl = await uploadImage(imageFile);
      }

      const eventData = {
        ...formData,
        imageUrl,
        userId: user.uid,
        createdAt: new Date(),
        status: "active",
        lastUpdated: new Date(),
      };

      const docRef = await addDoc(collection(firestore, "events"), eventData);
      toast.success("Event created successfully!");
      router.push(`/event/${docRef.id}`);
    } catch (error) {
      console.error("Error creating event:", error);
      setError("Failed to create event. Please try again.");
      toast.error("Failed to create event. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>,
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">Create New Event</h1>

          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="bg-red-50 border-l-4 border-red-400 p-4 mb-6"
            >
              <div className="flex">
                <div className="flex-shrink-0">
                  <FiX className="h-5 w-5 text-red-400" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              </div>
            </motion.div>
          )}

          <form onSubmit={handleSubmit} className="space-y-8">
            <div>
              <label className="block text-gray-700 mb-2">Event Category</label>
              <select
                name="category"
                value={formData.category}
                onChange={handleChange}
                required
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-[#f02e65] focus:border-[#f02e65]"
              >
                <option value="">Select a category</option>
                {categories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-gray-700 mb-2">Event Title</label>
              <input
                type="text"
                name="title"
                required
                value={formData.title}
                onChange={handleChange}
                placeholder="Enter event title"
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-[#f02e65] focus:border-[#f02e65]"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-gray-700 mb-2">Date</label>
                <input
                  type="date"
                  name="date"
                  required
                  value={formData.date}
                  onChange={handleChange}
                  min={new Date().toISOString().split("T")[0]}
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-[#f02e65] focus:border-[#f02e65]"
                />
              </div>
              <div>
                <label className="block text-gray-700 mb-2">Time</label>
                <input
                  type="time"
                  name="time"
                  required
                  value={formData.time}
                  onChange={handleChange}
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-[#f02e65] focus:border-[#f02e65]"
                />
              </div>
            </div>

            <div>
              <label className="block text-gray-700 mb-2">Location</label>
              <input
                type="text"
                name="location"
                required
                value={formData.location}
                onChange={handleChange}
                placeholder="Enter event location"
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-[#f02e65] focus:border-[#f02e65]"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-gray-700 mb-2">Capacity</label>
                <input
                  type="number"
                  name="capacity"
                  required
                  min="1"
                  value={formData.capacity}
                  onChange={handleChange}
                  placeholder="Number of guests"
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-[#f02e65] focus:border-[#f02e65]"
                />
              </div>
              <div>
                <label className="block text-gray-700 mb-2">Price</label>
                <input
                  type="number"
                  name="price"
                  required
                  min="0"
                  step="0.01"
                  value={formData.price}
                  onChange={handleChange}
                  placeholder="Event price"
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-[#f02e65] focus:border-[#f02e65]"
                />
              </div>
            </div>

            <div className="prose prose-sm w-full">
              <label className="block text-gray-700 mb-2">Description</label>
              <div className="border border-gray-300 rounded-md overflow-hidden">
                {editor && <Toolbar editor={editor} />}
                <EditorContent
                  editor={editor}
                  className="min-h-[200px] p-4 focus:outline-none"
                />
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-gray-700">Recurring Event</label>
                <div className="relative inline-block w-10 mr-2 align-middle select-none">
                  <input
                    type="checkbox"
                    name="isRecurring"
                    checked={formData.isRecurring}
                    onChange={(e) => {
                      setFormData(prev => ({
                        ...prev,
                        isRecurring: e.target.checked,
                        recurringFrequency: e.target.checked ? 'weekly' : undefined,
                        endDate: e.target.checked ? '' : undefined
                      }));
                    }}
                    className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer"
                  />
                  <label className="toggle-label block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer"></label>
                </div>
              </div>

              {formData.isRecurring && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-4"
                >
                  <div>
                    <label className="block text-gray-700 mb-2">Frequency</label>
                    <select
                      name="recurringFrequency"
                      value={formData.recurringFrequency}
                      onChange={handleChange}
                      required={formData.isRecurring}
                      className="w-full p-2 border border-gray-300 rounded-md focus:ring-[#f02e65] focus:border-[#f02e65]"
                    >
                      <option value="daily">Daily</option>
                      <option value="weekly">Weekly</option>
                      <option value="monthly">Monthly</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-gray-700 mb-2">End Date</label>
                    <input
                      type="date"
                      name="endDate"
                      value={formData.endDate}
                      onChange={handleChange}
                      required={formData.isRecurring}
                      min={formData.date}
                      className="w-full p-2 border border-gray-300 rounded-md focus:ring-[#f02e65] focus:border-[#f02e65]"
                    />
                  </div>
                </motion.div>
              )}
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-gray-700">Ticket Types</label>
                <button
                  type="button"
                  onClick={() => {
                    setFormData(prev => ({
                      ...prev,
                      ticketTypes: [
                        ...prev.ticketTypes,
                        { name: '', price: 0, quantity: 1 }
                      ]
                    }));
                  }}
                  className="text-[#f02e65] hover:text-[#ab073d] font-medium"
                >
                  + Add Ticket Type
                </button>
              </div>

              <AnimatePresence>
                {formData.ticketTypes.map((ticket, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="p-4 border border-gray-200 rounded-lg space-y-4"
                  >
                    <div className="flex justify-between items-center">
                      <h4 className="font-medium">Ticket Type #{index + 1}</h4>
                      <button
                        type="button"
                        onClick={() => {
                          setFormData(prev => ({
                            ...prev,
                            ticketTypes: prev.ticketTypes.filter((_, i) => i !== index)
                          }));
                        }}
                        className="text-red-500 hover:text-red-700"
                      >
                        <FiX className="h-5 w-5" />
                      </button>
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <label className="block text-gray-700 mb-2">Name</label>
                        <input
                          type="text"
                          value={ticket.name}
                          onChange={(e) => {
                            const newTicketTypes = [...formData.ticketTypes];
                            newTicketTypes[index].name = e.target.value;
                            setFormData(prev => ({
                              ...prev,
                              ticketTypes: newTicketTypes
                            }));
                          }}
                          placeholder="e.g., VIP, Regular"
                          className="w-full p-2 border border-gray-300 rounded-md focus:ring-[#f02e65] focus:border-[#f02e65]"
                        />
                      </div>

                      <div>
                        <label className="block text-gray-700 mb-2">Price</label>
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          value={ticket.price}
                          onChange={(e) => {
                            const newTicketTypes = [...formData.ticketTypes];
                            newTicketTypes[index].price = parseFloat(e.target.value);
                            setFormData(prev => ({
                              ...prev,
                              ticketTypes: newTicketTypes
                            }));
                          }}
                          className="w-full p-2 border border-gray-300 rounded-md focus:ring-[#f02e65] focus:border-[#f02e65]"
                        />
                      </div>

                      <div>
                        <label className="block text-gray-700 mb-2">Quantity</label>
                        <input
                          type="number"
                          min="1"
                          value={ticket.quantity}
                          onChange={(e) => {
                            const newTicketTypes = [...formData.ticketTypes];
                            newTicketTypes[index].quantity = parseInt(e.target.value);
                            setFormData(prev => ({
                              ...prev,
                              ticketTypes: newTicketTypes
                            }));
                          }}
                          className="w-full p-2 border border-gray-300 rounded-md focus:ring-[#f02e65] focus:border-[#f02e65]"
                        />
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            <div>
              <label className="block text-gray-700 mb-2">Event Image</label>
              <div
                className="flex flex-col items-center space-y-4 w-full"
                onDragOver={(e) => {
                  e.preventDefault();
                  e.currentTarget.classList.add("border-[#f02e65]");
                }}
                onDragLeave={(e) => {
                  e.preventDefault();
                  e.currentTarget.classList.remove("border-[#f02e65]");
                }}
                onDrop={(e) => {
                  e.preventDefault();
                  e.currentTarget.classList.remove("border-[#f02e65]");
                  const file = e.dataTransfer.files[0];
                  if (file) {
                    handleImageChange({ target: { files: [file] } });
                  }
                }}
              >
                {imagePreview ? (
                  <div className="relative w-full h-64 group rounded-lg overflow-hidden">
                    <img
                      src={imagePreview}
                      alt="Event preview"
                      className="object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                      <button
                        type="button"
                        onClick={() => {
                          setImageFile(null);
                          setImagePreview("");
                        }}
                        className="bg-white text-gray-800 px-4 py-2 rounded-full hover:bg-gray-100 transition-colors"
                      >
                        Change Image
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="w-full h-64 border-2 border-dashed border-gray-300 rounded-lg p-8 flex flex-col items-center justify-center text-center hover:border-[#f02e65] transition-colors">
                    <svg
                      className="w-12 h-12 text-gray-400 mb-4"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                      />
                    </svg>
                    <p className="text-gray-600 mb-2">Drag and drop your event image here, or</p>
                    <label className="cursor-pointer bg-[#f02e65] text-white px-4 py-2 rounded-full hover:bg-[#ab073d] transition-colors">
                      Browse Files
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageChange}
                        className="hidden"
                        disabled={loading}
                      />
                    </label>
                    <p className="text-sm text-gray-500 mt-4">
                      Maximum file size: 5MB. Supported formats: JPG, PNG, GIF
                    </p>
                  </div>
                )}
                {imageError && (
                  <p className="text-red-500 text-sm mt-1">{imageError}</p>
                )}
                {uploadProgress > 0 && uploadProgress < 100 && (
                  <div className="w-full">
                    <div className="w-full bg-gray-200 rounded-full h-2.5 mb-1">
                      <div
                        className="bg-[#f02e65] h-2.5 rounded-full transition-all duration-300"
                        style={{ width: `${uploadProgress}%` }}
                      ></div>
                    </div>
                    <p className="text-sm text-gray-500 text-center">
                      Uploading... {uploadProgress}%
                    </p>
                  </div>
                )}
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className={`w-full bg-[#f02e65] text-white px-8 py-3 rounded-xl text-lg font-semibold 
                ${loading ? "opacity-50 cursor-not-allowed" : "hover:bg-[#ab073d]"} 
                transition-colors flex items-center justify-center gap-2`}
            >
              {loading ? (
                <>
                  <svg
                    className="animate-spin h-5 w-5 text-white"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    ></circle>
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                  </svg>
                  Creating Event...
                </>
              ) : (
                "Create Event"
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

<style jsx>{`
  .toggle-checkbox:checked {
    right: 0;
    border-color: #f02e65;
  }
  .toggle-checkbox:checked + .toggle-label {
    background-color: #f02e65;
  }
  .toggle-checkbox {
    right: 0;
    transition: all 0.3s;
  }
  .toggle-label {
    transition: all 0.3s;
  }
  .ProseMirror {
    > * + * {
      margin-top: 0.75em;
    }
    
    ul,
    ol {
      padding: 0 1rem;
    }

    h1 {
      font-size: 2em;
    }

    h2 {
      font-size: 1.5em;
    }

    h3 {
      font-size: 1.25em;
    }

    code {
      background-color: rgba(#616161, 0.1);
      color: #616161;
    }

    pre {
      background: #0D0D0D;
      color: #FFF;
      font-family: 'JetBrainsMono', monospace;
      padding: 0.75rem 1rem;
      border-radius: 0.5rem;

      code {
        color: inherit;
        padding: 0;
        background: none;
        font-size: 0.8rem;
      }
    }

    img {
      max-width: 100%;
      height: auto;
    }

    blockquote {
      padding-left: 1rem;
      border-left: 2px solid rgba(#0D0D0D, 0.1);
    }

    hr {
      border: none;
      border-top: 2px solid rgba(#0D0D0D, 0.1);
      margin: 2rem 0;
    }
  }
`}</style>
